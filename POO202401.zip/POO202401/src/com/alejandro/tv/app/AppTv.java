package com.alejandro.tv.app;

public class AppTv {
    public static void main(String[] args) {
        System.out.println("TV");
    }
}
