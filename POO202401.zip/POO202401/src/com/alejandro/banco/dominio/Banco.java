package com.alejandro.banco.dominio;

public class Banco {
    public String nombre;
    public String gerente;
}
