package com.alejandro.banco.dominio;

public class Persona {
    public String nombre;
    public String identificacion;
    public int edad;
}
